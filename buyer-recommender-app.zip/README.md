# Buyer Recommendation App

This app uses semantic similarity to recommend buyers for M&A targets.